				
			        CrazyChip8 32Bit ASM Build
                                          v0.2


Legal Disclaimer:
-----------------

YOU USE THIS PROGRAM AT YOUR OWN RISK, I CANNOT BE HELD RESPONSIBLE FOR ANY 
LOSS OR DAMAGE CAUSED.

THIS PROGRAM REQUIRES THE GAME ROMS. THESE ROMS ARE TO BE FOUND AROUND THE WEB.
BUT YOU ARE NOT LEGALLY ENTITLED TO USE THEM IF YOU DON'T OWN THEM. 
I CANNOT BE HELD RESPONSIBLE FOR ANY REACH OF COPYRIGHT.

THIS PROGRAM DOES NOT SHIP WITH ROM IMAGES. DO NOT DISTRIBUTE THIS
PROGRAM WITH ROM IMAGES.

PLEASE DO NOT ASK ME TO SUPPLY YOU WITH ROM IMAGES OR ASK ME WHERE TO FIND 
THEM.



Some Words:
-----------

CrazyChip8 is an Chip-8 emulator which uses to run games like: 'pong', 'space Invaders'..etc.
it emulates the Chip8 only (not SuperChip8 extended).
CrazyChip8 emulates few games, some games has InGame gfx problems (lacking SChip8 support).
some Game will have diffrent Input.
the usual input are: NumPad0..NumPad9, '/', '*','Delete','-','+','Enter'


Special Thanks:
--------------
- Jan_Klass (FBA) for some help on learning to fix DX problems ;)
- GoldRoad for his nice starting tutorial on approaching emulators.
- Zophar's Domain, for the great information & docs.
- Win32ASM Community.
- KetilO, for this great Win32Asm IDE called 'RadASM'.

